Opened from a network drive, without downloading it.
